Geese Lightning
