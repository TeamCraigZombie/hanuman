<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="wood_tileset_3" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="wood_tileset_3.png" width="512" height="512"/>
</tileset>
