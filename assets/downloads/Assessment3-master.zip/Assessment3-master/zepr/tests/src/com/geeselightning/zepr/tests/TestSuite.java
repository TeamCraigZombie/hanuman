package com.geeselightning.zepr.tests;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)

@Suite.SuiteClasses({
        CharacterTest.class,
        PlayerTest.class,
        ZombieTest.class,
        PowerUpTest.class
})

public class TestSuite {
}