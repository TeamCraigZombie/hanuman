<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="build_atlas" tilewidth="16" tileheight="16" tilecount="4096" columns="64">
 <image source="build_atlas.png" width="1024" height="1024"/>
</tileset>
