<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="floor_tileset" tilewidth="16" tileheight="16" tilecount="2048" columns="64">
 <image source="tileset.png" width="1024" height="512"/>
</tileset>
