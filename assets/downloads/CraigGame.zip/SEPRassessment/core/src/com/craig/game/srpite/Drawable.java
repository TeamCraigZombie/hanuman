package com.craig.game.srpite;

import com.badlogic.gdx.graphics.g2d.SpriteBatch;

public class Drawable
{
    public int X;
    public int Y;

    public Drawable(int x, int y)
    {
        X = x;
        Y = y;
    }

    public void draw(SpriteBatch target)
    {

    }
}
